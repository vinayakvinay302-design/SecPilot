# SecPilot

A single-file, fully working prototype dashboard. No build step, no dependencies to install.

## Upload to GitHub
1. Create a new repository on GitHub (e.g. `secpilot`).
2. On the repo page, click **Add file → Upload files**.
3. Drag in `index.html` (and this README if you want).
4. Commit.

## Turn it into a live website with GitHub Pages (free)
1. In the repo, go to **Settings → Pages**.
2. Under "Build and deployment", set **Source** to "Deploy from a branch".
3. Set the branch to `main` and the folder to `/ (root)`. Save.
4. GitHub gives you a URL like `https://<your-username>.github.io/secpilot/` within a minute or two.

## Or deploy to Netlify instead (also free, usually faster)
Go to https://app.netlify.com/drop and drag `index.html` straight in — you'll get a live URL immediately, no GitHub required.
